<?php 
namespace teacher{
    class joiningDetails{
        function BirthDate(){
            echo "22-02-24";
        }
    }
   
}