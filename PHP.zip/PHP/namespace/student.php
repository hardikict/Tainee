<?php 
namespace student{
    class joiningDetails{
        function joiningDate(){
            echo "02-02-23";
        }
    }
    
}